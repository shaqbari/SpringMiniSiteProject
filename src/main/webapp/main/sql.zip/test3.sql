-- 2017.06.08 Spring MVC -table����
/*
����Ʈ => ��ť�� �ڵ� => (��ŷ)
Create Table food_category(
	cate_no NUMBER
	, category VARCHAR2(200) CONSTRAINT cate_title_nn NOT NULL
	, subject VARCHAR2(200) CONSTRAINT cate_sub_nn NOT NULL
	, link VARCHAR2(200) CONSTRAINT cate_link_nn NOT NULL
	, poster VARCHAR2(200) CONSTRAINT cate_poster_nn NOT NULL
	, CONSTRAINT cate_no_pk PRIMARY KEY(cate_no)
);
*/
--constraint�� �̸��� �־�� ������ �����ϴ�.
--���������� table-level constraint��.
/*
CREATE TABLE food_info(
	food_no NUMBER
	, title VARCHAR2(200) CONSTRAINT food_title_nn NOT NULL
	, poster VARCHAR2(260) CONSTRAINT food_poster_nn NOT NULL
	, address VARCHAR2(200) CONSTRAINT food_address_nn NOT NULL
	, price VARCHAR2(200)
	, food_type VARCHAR2(100)
	, cate_no NUMBER
	, avg NUMBER
	, good NUMBER
	, soso NUMBER
	, bad NUMBER
	, CONSTRAINT food_no_pk PRIMARY KEY(food_no)
	, CONSTRAINT food_cno_fk FOREIGN KEY(cate_no) REFERENCES food_category(cate_no)
);*/
/* a.jpg, b.jpg, c.jpg
    10, 100, 300

    ����
	����
	 1, CGV
	 2, �ް��ڽ�
	 3, �Ե��ó׸�
	 4, ���� ����

	�븳��
	 ����: 1, 2, 4
*/

Drop Table dataBoard;
Drop Table dataReply;
Drop Sequence db_no_seq;
Drop Sequence dr_no_seq;

/*
Create Table dataBoard(
	no Number
	, name Varchar2(34) Constraint db_name_nn Not Null
	, subject Varchar2(1000) Constraint db_sub_nn Not Null
	, content Clob Constraint db_cont_nn Not Null
	, pwd Varchar2(10)	Constraint db_pwd_nn Not Null
	, regdate Date Default Sysdate
	, hit Number Default 0
	, filename Varchar2(2000)
	, filesize Varchar2(2000)
	, filecount Number  Default 0
	, Constraint db_no_pk Primary Key(no)
);

Create Table dataReply(
	no Number
	, bno Number
	, id Varchar2(20) Constraint dr_id_nn Not Null
	, name Varchar2(34) Constraint dr_name_nn Not Null
	, msg Clob Constraint dr_msg_nn Not Null
	, regdate Date Default sysdate
	, group_id Number
	, group_step Number
	, group_tab Number
	, root Number
	, depth Number
	,  Constraint dr_no_pk Primary Key(no)
	,  Constraint dr_bno_fk Foreign Key(bno) References dataBoard(no)

);


Create Sequence db_no_seq
	start with 1
	increment by 1
	nocycle
	nocache;

Create Sequence dr_no_seq
	start with 1
	increment by 1
	nocycle
	nocache;
*/